<h1 align="center"> Projeto SCOA 👨‍🎓</h1>

<h5 align="center">Fala, galera. Bem-vindos ao nosso reposótio privado para desenvolvimento dessa bagaça do Sildenir haha</h5>


#### ⚒️ Ferramentas

Como combinamos, o projeto será desenvolvido na linguagem Java, de preferência, com as IDE's Eclipse ou VSCode.
O banco de dados será desenvolvido e criado na linguagem SQL utiliizando, de preferência, o MySQL Workbench para manutenções no banco de dados.
<br/>
<br/>
### Status: Em desenvolvimento ⌛

<hr>

<i><h5 align="center">"Investir em conhecimento sempre renderá os melhores juros" 💭</h5></i>