package Controller;
import view.*;

public class Controller {

	public static void main(String[] args) {
		new Login_view();
	}
}